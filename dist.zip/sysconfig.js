"use strict";

/** 应用在运行状态下的全局配置 */

(function(global) {
  global.LOCAL_CONFIG = {
    API_HOME: "/",
  };
})(window);
